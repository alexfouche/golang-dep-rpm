
General maintainers:
    sam boyer (@sdboyer)

* dep
  * `init` command: Carolyn Van Slyck (@carolynvs)
  * `ensure` command: Ibrahim AshShohail (@ibrasho)
  * `status` command: Sunny (@darkowlzz)
  * testing harness: (vacant)
* gps
  * solver: (vacant)
  * source manager: (vacant)
  * root deduction: (vacant)
  * source/vcs interaction: (vacant)
  * caching: Jordan Krage (@jmank88)
  * pkgtree: (vacant)
  * versions and constraints: (vacant)
